JAVA SANDBOX
------------
Java Sandbox, Copyright (c) 2015, Brendan Batliner
RSyntaxTextArea, Copyright (c) 2012, Robert Futrell
See the license directory for more information.

To run:
    java -jar bin/Launcher.jar
or
    Double click bin/Launcher.jar
